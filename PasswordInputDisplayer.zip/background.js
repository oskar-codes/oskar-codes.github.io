chrome.browserAction.onClicked.addListener(function(tab) {
  var script = `
    var inputs = document.getElementsByTagName("input");
    for (var i=0; i<inputs.length; i++) {
      var input = inputs[i];
      if (input.type === "password") {
        input.setAttribute("type", "text");
      }
    }
  `
  chrome.tabs.executeScript({
    code: script
  });
});

var contextMenuItem = {
  "id": "showPassword",
  "title": "Show password",
  "contexts": ["editable"]
}

chrome.contextMenus.create(contextMenuItem);

chrome.contextMenus.onClicked.addListener(function(clickData) {
  if (clickData.menuItemId === "showPassword") {
    var script = `
      var input = document.activeElement;
      if (input.type === "password") {
        input.setAttribute("type", "text");
      }
    `
    chrome.tabs.executeScript({
      code: script
    });
  }
})