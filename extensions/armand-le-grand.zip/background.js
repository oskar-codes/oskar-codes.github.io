/*var deepFry = false;

chrome.browserAction.onClicked.addListener(function(tab) {
  deepFry = !deepFry;
  chrome.tabs.query({} ,function (tabs) {
    for (var i = 0; i < tabs.length; i++) {
      chrome.tabs.executeScript(tabs[i].id, {
        code: getScript()
      },_=>{});
    }
  });
});*/

chrome.history.onVisited.addListener(function() {
  chrome.tabs.executeScript({
    code: `
    var armandLeGrandLink = "https://cdn.discordapp.com/attachments/547487202423341112/703127662419247114/ARMAND-Logo-Transparent.png"
    window.setTimeout(function(e) {    
      if (location.href.includes("google.com")) {
        // Armand logo on home page
        try {
          document.querySelector("img#hplogo").src = armandLeGrandLink;
          document.querySelector("img#hplogo").srcset = "";
          document.querySelector("img#hplogo").style.paddingTop = "50px";
          document.querySelector("img#hplogo").style.height = "200px";
        } catch (e) {

        }

        // Armand search button
        try {
          document.querySelector(".FPdoLc.tfB0Bf").children[0].children[0].setAttribute("value", "Armand Search");
        } catch (e) {
        
        }

        // Logo on all tabs except image tab
        try {
          document.querySelector("a#logo").children[0].src = armandLeGrandLink;
          document.querySelector("a#logo").children[0].style.height = "75px";
          document.querySelector("a#logo").children[0].style.marginTop = "-25px";
        } catch(e) {

        }

        // Logo on image tab
        try {
          let parent = document.querySelector("a.F1hUFe.jbTlie");
          parent.removeChild(parent.children[0]);

          parent.style.background = "url("+ armandLeGrandLink +")";
          parent.style.width = "100px";
          parent.style.height = "40px";
          parent.style.backgroundSize = "70%";
          parent.style.backgroundPosition = "center";
          parent.style.backgroundRepeat = "no-repeat";
        } catch(e) {

        }

        // Armand logo on account page
        try {
          let style = document.createElement("style");
          style.innerHTML = \`
            .gb_tc .gb_2c:before {
              content: "" !important;
              background: url(\`+ armandLeGrandLink +\`);
              background-size: 100%;
              background-position: center;
              background-repeat: no-repeat;
            }
          \`

          document.head.appendChild(style);
        } catch (e) {

        }

        // Replace all "Google" by "Armand"
        try {
          replaceAllGoogles();
        } catch (e) {
          
        }
        window.setInterval(() => {
          try {
            replaceAllGoogles();
          } catch(e) {

          }
        }, 1e3);
      }
    },50);

    function replaceAllGoogles() {
      var textNodes = getTextNodesIn(document.body);
      for (var i=0; i<textNodes.length; i++) {
        var node = textNodes[i];
        if (node.textContent) {
          node.textContent = node.textContent.replace(/google/g,"armand").replace(/Google/g,"Armand");
        }
      }
    }

    function getTextNodesIn(elem, opt_fnFilter) {
      var textNodes = [];
      if (elem) {
        for (var nodes = elem.childNodes, i = nodes.length; i--;) {
          var node = nodes[i], nodeType = node.nodeType;
          if (nodeType == 3) {
            if (!opt_fnFilter || opt_fnFilter(node, elem)) {
              textNodes.push(node);
            }
          }
          else if (nodeType == 1 || nodeType == 9 || nodeType == 11) {
            textNodes = textNodes.concat(getTextNodesIn(node, opt_fnFilter));
          }
        }
      }
      return textNodes;
    }
    `
  },_=>{});
});

/*try {
          document.querySelector(".logo").children[0].children[0].src = "https://cdn.discordapp.com/attachments/547487202423341112/703127662419247114/ARMAND-Logo-Transparent.png";
        } catch (e) {

        }
        
        try {
          document.querySelector(".doodle").children[0].children[0].src = "https://cdn.discordapp.com/attachments/547487202423341112/703127662419247114/ARMAND-Logo-Transparent.png";
        } catch (e) {

        }
        
        try {
          document.querySelector(".ZbYMvd").children[0].children[0].src = "https://cdn.discordapp.com/attachments/547487202423341112/703127662419247114/ARMAND-Logo-Transparent.png";
        } catch (e) {
          
        }

        try {
          document.querySelector("img[src*='google.com/logos']").src = "https://cdn.discordapp.com/attachments/547487202423341112/703127662419247114/ARMAND-Logo-Transparent.png";
        } catch (e) {

        }

        try {
          let styleSheet = document.createElement("style");
          styleSheet.innerHTML = "a[title*='Google'] span::before { content: url('https://cdn.discordapp.com/attachments/547487202423341112/703127662419247114/ARMAND-Logo-Transparent.png') !important; }"
          document.head.appendChild(styleSheet);
        } catch (e) {
        
        }*/