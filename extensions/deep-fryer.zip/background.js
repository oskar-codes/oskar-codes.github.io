var deepFry = false;

chrome.browserAction.onClicked.addListener(function(tab) {
  deepFry = !deepFry;
  chrome.tabs.query({} ,function (tabs) {
    for (var i = 0; i < tabs.length; i++) {
      chrome.tabs.executeScript(tabs[i].id, {
        code: getScript()
      },_=>{});
    }
  });
});

chrome.history.onVisited.addListener(function() {
  chrome.tabs.executeScript({
    code: getScript()
  },_=>{});
});

const getScript = () => deepFry ? `document.body.style.setProperty("filter", "brightness(125%) contrast(1000%) saturate(300%)");` : `document.body.style.setProperty("filter", "");`