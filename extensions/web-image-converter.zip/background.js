chrome.runtime.onInstalled.addListener(function() {
  chrome.contextMenus.create({
    "id": "convertToPng",
    "title": "Convert to PNG",
    "contexts": ["image"]
  });
  chrome.contextMenus.create({
    "id": "convertToJpg",
    "title": "Convert to JPG",
    "contexts": ["image"]
  });
});

chrome.contextMenus.onClicked.addListener(function(clickData) {
  var script;
  var execute = false;
  if (clickData.menuItemId === "convertToJpg") {
    script = getScript("jpeg")
    execute = true;
  } else if (clickData.menuItemId === "convertToPng") {
    script = getScript("png");
    execute = true;
  }
  if (execute) {
    chrome.tabs.executeScript({
      code: script
    });
  }
});

function getScript(type) {
  return `
    function removeDivs() {
      divsToRemove = document.getElementsByClassName("webImageConverterDivs");
      for (var i=divsToRemove.length - 1; i>=0; i--) {
        divsToRemove[i].parentElement.removeChild(divsToRemove[i]);
      }
    }

    function convertImageToCanvas(image) {
      var canvas = document.createElement("canvas");
      canvas.width = image.width;
      canvas.height = image.height;
      var c = canvas.getContext("2d");
      
      c.drawImage(image, 0, 0);
      
      return canvas;
    }
    function convertCanvasToImage(canvas) {
      var image = new Image();
      image.src = canvas.toDataURL("image/${type}");
      return image;
    }

    try {
      var img = document.elementFromPoint(webImageConverterCursorX, webImageConverterCursorY);
      var canvas = convertImageToCanvas(img);
      var newImg = convertCanvasToImage(canvas);
      var div = document.createElement("div");
      div.setAttribute("style","overflow: scroll; transition: all 0.3s; padding: 30px; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0); width: 60vw; height: 60vh; background-color: #171717; border-radius: 10px; z-index: 9999999999;");
      
      var header = document.createElement("h1");
      header.style.fontFamily = "'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif";
      header.style.color = "white";
      header.innerHTML = "Here's your image, converted to ${type.toUpperCase()}:";

      div.appendChild(header);
      div.appendChild(newImg);
      div.classList.add("webImageConverterDivs");

      var background = document.createElement("div");
      background.setAttribute("style", "z-index: 999999999; position: fixed; left: 0; top: 0; width: 100vw; height: 100vh; background-color: #00000099");
      background.classList.add("webImageConverterDivs");

      background.onclick = function() {
        removeDivs();
      }

      document.body.appendChild(background);
      document.body.appendChild(div);

      window.setTimeout(function(e) {
        div.style.transform = "translate(-50%, -50%) scale(1)";
      },100)
    } catch(e) {
      if (e.toString().includes("Tainted canvases may not be exported")) {
        alert("An error occured. Try opening the image in a new tab, and then convert.");
      } else if (e.toString().includes("webImageConverterCursorX")) {
        alert("An error occured. Try reloading the page.");
      } else if (e.toString().includes("Failed to execute 'drawImage' on 'CanvasRenderingContext2D'")) {
        alert("The element you are trying to convert doesn't seem to be a valid image.");
      } else {
        alert(e);
      }
    }
  `
}