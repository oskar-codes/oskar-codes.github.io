window.webImageConverterCursorX = 0;
window.webImageConverterCursorY = 0;
document.onmousemove = function(e){
  window.webImageConverterCursorX = e.pageX - window.pageXOffset;
  window.webImageConverterCursorY = e.pageY - window.pageYOffset;
}