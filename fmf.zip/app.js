var images = document.querySelectorAll("#images img");
var tags = new Set();

for (var i=0; i<images.length; i++) {
  var img = images[i];
  if (img.hasAttribute("data-tag")) {
    tags.add(img.getAttribute("data-tag"));
  }
}

tags = Array.from(tags);
var tagContainer = document.getElementById("tags");
tags.forEach((e, i) => {
  tagContainer.innerHTML += `<span onclick="openTag('${e}')" class="tag">${e}</span>${i + 1 === tags.length ? "" : ", "}`
});

imagesContainer = document.querySelector("#images");
function openTag(t) {
  images.forEach((e) => {
    if (e.getAttribute("data-tag") === t) {
      e.style.display = "block";
    } else {
      e.style.display = "none";
    }
  })

  imagesContainer.style.top = "0vh"
}

function closeImages() {
  imagesContainer.style.top = "100vh"
}